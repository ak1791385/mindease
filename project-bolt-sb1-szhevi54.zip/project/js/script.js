// MindEase - Interactive JavaScript Functions

// ============ GLOBAL VARIABLES ============
let breathingInterval;
let isBreathing = false;
let quizAnswers = [];
let currentQuestion = 0;
let scrollRevealObserver;

// Positive affirmations array
const affirmations = [
    "You are stronger than you think and capable of overcoming any challenge.",
    "Your mental health matters, and seeking help is a sign of courage.",
    "Every day is a new opportunity to grow and heal.",
    "You deserve love, respect, and happiness in your life.",
    "Your feelings are valid, and it's okay to not be okay sometimes.",
    "You have the power to create positive change in your life.",
    "You are not alone in your struggles - support is always available.",
    "Your potential is limitless, and your future is bright.",
    "You are worthy of all the good things life has to offer.",
    "Taking care of your mental health is an act of self-love.",
    "You have survived difficult times before, and you will again.",
    "Your journey is unique, and progress isn't always linear.",
    "You are brave for facing your challenges head-on.",
    "Your mental health journey is valid, regardless of how it looks.",
    "You have the strength to turn your struggles into wisdom.",
    "You matter, your life has value, and the world is better with you in it.",
    "It's okay to take things one day at a time.",
    "You are learning and growing with every experience.",
    "Your self-care is not selfish - it's necessary.",
    "You have the right to prioritize your mental well-being."
];

// Quiz questions for stress assessment
const quizQuestions = [
    {
        question: "Over the past week, how often have you felt nervous or anxious?",
        options: ["Never", "Rarely", "Sometimes", "Often", "Always"]
    },
    {
        question: "How often have you had trouble sleeping due to worries?",
        options: ["Never", "Rarely", "Sometimes", "Often", "Always"]
    },
    {
        question: "How overwhelmed do you feel with your current responsibilities?",
        options: ["Not at all", "Slightly", "Moderately", "Very", "Extremely"]
    }
];

// ============ INITIALIZATION ============
document.addEventListener('DOMContentLoaded', function() {
    initializeComponents();
    attachEventListeners();
    loadMoodHistory();
    initializeAnimations();
    initializeScrollReveal();
});

function initializeComponents() {
    // Initialize any components that need setup
    console.log('MindEase website initialized');
    
    // Add smooth scrolling to anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Initialize navbar scroll effect
    initializeNavbarScroll();
    
    // Add loading animation to page
    document.body.classList.add('loaded');
}

function attachEventListeners() {
    // Breathing Exercise
    const startBreathingBtn = document.getElementById('startBreathing');
    const stopBreathingBtn = document.getElementById('stopBreathing');
    
    if (startBreathingBtn) {
        startBreathingBtn.addEventListener('click', startBreathingExercise);
    }
    
    if (stopBreathingBtn) {
        stopBreathingBtn.addEventListener('click', stopBreathingExercise);
    }

    // Mood Tracker
    const moodBtns = document.querySelectorAll('.mood-btn');
    const saveMoodBtn = document.getElementById('saveMood');
    
    moodBtns.forEach(btn => {
        btn.addEventListener('click', selectMood);
    });
    
    if (saveMoodBtn) {
        saveMoodBtn.addEventListener('click', saveMood);
    }

    // Stress Quiz
    const quizOptions = document.querySelectorAll('.quiz-option');
    const retakeQuizBtn = document.getElementById('retakeQuiz');
    
    quizOptions.forEach(option => {
        option.addEventListener('click', selectQuizAnswer);
    });
    
    if (retakeQuizBtn) {
        retakeQuizBtn.addEventListener('click', retakeQuiz);
    }

    // Affirmations
    const newAffirmationBtn = document.getElementById('newAffirmation');
    if (newAffirmationBtn) {
        newAffirmationBtn.addEventListener('click', showNewAffirmation);
    }

    // Contact Form
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactForm);
    }

    // Play Meditation Button
    const playMeditationBtn = document.getElementById('playMeditation');
    if (playMeditationBtn) {
        playMeditationBtn.addEventListener('click', playMeditation);
    }
    
    // Add hover effects to cards
    addCardHoverEffects();
    
    // Add click animations to buttons
    addButtonClickEffects();
}

// ============ ENHANCED ANIMATIONS ============
function initializeAnimations() {
    // Add staggered animations to elements
    const animatedElements = document.querySelectorAll('.fade-in, .scale-in, .fade-in-left, .fade-in-right');
    
    animatedElements.forEach((element, index) => {
        element.style.animationDelay = `${index * 0.1}s`;
    });
    
    // Add floating animation to hero elements
    const floatingElements = document.querySelectorAll('.floating-card, .hero-content');
    floatingElements.forEach(element => {
        element.classList.add('float-animation');
    });
    
    // Add pulse animation to important buttons
    const importantButtons = document.querySelectorAll('.btn-primary, .btn-danger');
    importantButtons.forEach(button => {
        if (button.textContent.includes('Crisis') || button.textContent.includes('Emergency')) {
            button.classList.add('pulse-animation');
        }
    });
}

function initializeScrollReveal() {
    // Create intersection observer for scroll animations
    scrollRevealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
                // Add staggered animation to child elements
                const children = entry.target.querySelectorAll('.card, .btn, .icon-wrapper');
                children.forEach((child, index) => {
                    setTimeout(() => {
                        child.style.transform = 'translateY(0)';
                        child.style.opacity = '1';
                    }, index * 100);
                });
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    // Observe elements for scroll reveal
    const revealElements = document.querySelectorAll('.quick-link-card, .tool-card, .issue-card, .article-card, .goal-card, .reason-card');
    revealElements.forEach(element => {
        element.classList.add('scroll-reveal');
        scrollRevealObserver.observe(element);
    });
}

function addCardHoverEffects() {
    const cards = document.querySelectorAll('.quick-link-card, .tool-card, .issue-card, .article-card');
    
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px) scale(1.02)';
            this.style.boxShadow = 'var(--shadow-2xl)';
            
            // Add shimmer effect
            const shimmer = document.createElement('div');
            shimmer.className = 'shimmer-effect';
            shimmer.style.cssText = `
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
                animation: shimmer 0.8s ease-out;
                pointer-events: none;
                z-index: 1;
            `;
            this.style.position = 'relative';
            this.appendChild(shimmer);
            
            setTimeout(() => {
                if (shimmer.parentNode) {
                    shimmer.parentNode.removeChild(shimmer);
                }
            }, 800);
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = '';
            this.style.boxShadow = '';
        });
    });
}

function addButtonClickEffects() {
    const buttons = document.querySelectorAll('.btn');
    
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Create ripple effect
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.cssText = `
                position: absolute;
                width: ${size}px;
                height: ${size}px;
                left: ${x}px;
                top: ${y}px;
                background: rgba(255, 255, 255, 0.3);
                border-radius: 50%;
                transform: scale(0);
                animation: ripple 0.6s ease-out;
                pointer-events: none;
            `;
            
            this.style.position = 'relative';
            this.style.overflow = 'hidden';
            this.appendChild(ripple);
            
            setTimeout(() => {
                if (ripple.parentNode) {
                    ripple.parentNode.removeChild(ripple);
                }
            }, 600);
        });
    });
}

// Add ripple animation keyframes
const rippleStyle = document.createElement('style');
rippleStyle.textContent = `
    @keyframes ripple {
        to {
            transform: scale(2);
            opacity: 0;
        }
    }
`;
document.head.appendChild(rippleStyle);
// ============ NAVBAR SCROLL EFFECT ============
function initializeNavbarScroll() {
    const navbar = document.querySelector('.navbar');
    if (!navbar) return;

    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
}

// ============ BREATHING EXERCISE ============
function startBreathingExercise() {
    if (isBreathing) return;
    
    isBreathing = true;
    const circle = document.getElementById('breathingCircle');
    const text = document.getElementById('breathingText');
    const startBtn = document.getElementById('startBreathing');
    const stopBtn = document.getElementById('stopBreathing');
    
    startBtn.disabled = true;
    stopBtn.disabled = false;
    
    // Add breathing start animation
    circle.style.transform = 'scale(1.1)';
    setTimeout(() => {
        circle.style.transform = '';
    }, 300);
    
    let phase = 'breathe-in'; // breathe-in, hold, breathe-out
    let phaseTime = 0;
    const phases = {
        'breathe-in': { duration: 4000, text: 'Breathe In', class: 'breathe-in' },
        'hold': { duration: 4000, text: 'Hold', class: 'breathe-in' },
        'breathe-out': { duration: 4000, text: 'Breathe Out', class: 'breathe-out' }
    };
    
    function updateBreathing() {
        const currentPhase = phases[phase];
        text.textContent = currentPhase.text;
        circle.className = `breathing-circle ${currentPhase.class}`;
        
        phaseTime += 100;
        
        if (phaseTime >= currentPhase.duration) {
            phaseTime = 0;
            switch(phase) {
                case 'breathe-in':
                    phase = 'hold';
                    break;
                case 'hold':
                    phase = 'breathe-out';
                    break;
                case 'breathe-out':
                    phase = 'breathe-in';
                    break;
            }
        }
    }
    
    breathingInterval = setInterval(updateBreathing, 100);
}

function stopBreathingExercise() {
    if (!isBreathing) return;
    
    isBreathing = false;
    clearInterval(breathingInterval);
    
    const circle = document.getElementById('breathingCircle');
    const text = document.getElementById('breathingText');
    const startBtn = document.getElementById('startBreathing');
    const stopBtn = document.getElementById('stopBreathing');
    
    circle.className = 'breathing-circle';
    text.textContent = 'Click Start';
    startBtn.disabled = false;
    stopBtn.disabled = true;
    
    // Add stop animation
    circle.style.transform = 'scale(0.9)';
    setTimeout(() => {
        circle.style.transform = '';
    }, 300);
}

// ============ MOOD TRACKER ============
function selectMood(event) {
    // Remove selected class from all mood buttons
    document.querySelectorAll('.mood-btn').forEach(btn => {
        btn.classList.remove('selected');
    });
    
    // Add selected class to clicked button
    event.target.classList.add('selected');
    
    // Add selection animation
    event.target.style.transform = 'scale(1.2) rotate(10deg)';
    setTimeout(() => {
        event.target.style.transform = '';
    }, 300);
}

function saveMood() {
    const selectedMood = document.querySelector('.mood-btn.selected');
    const notes = document.getElementById('moodNotes').value;
    
    if (!selectedMood) {
        alert('Please select a mood first!');
        return;
    }
    
    const moodData = {
        mood: selectedMood.dataset.mood,
        emoji: selectedMood.textContent,
        notes: notes,
        date: new Date().toLocaleDateString(),
        timestamp: new Date().toISOString()
    };
    
    // Save to localStorage
    let moodHistory = JSON.parse(localStorage.getItem('moodHistory') || '[]');
    moodHistory.unshift(moodData); // Add to beginning of array
    
    // Keep only last 10 entries
    if (moodHistory.length > 10) {
        moodHistory = moodHistory.slice(0, 10);
    }
    
    localStorage.setItem('moodHistory', JSON.stringify(moodHistory));
    
    // Update display
    updateMoodHistory();
    
    // Reset form
    selectedMood.classList.remove('selected');
    document.getElementById('moodNotes').value = '';
    
    // Show success message
    showToast('Mood saved successfully!', 'success');
    
    // Add success animation
    const saveMoodBtn = document.getElementById('saveMood');
    saveMoodBtn.classList.add('bounce-in');
    setTimeout(() => {
        saveMoodBtn.classList.remove('bounce-in');
    }, 1000);
}

function loadMoodHistory() {
    updateMoodHistory();
}

function updateMoodHistory() {
    const moodHistory = JSON.parse(localStorage.getItem('moodHistory') || '[]');
    const entriesContainer = document.getElementById('moodEntries');
    
    if (!entriesContainer) return;
    
    if (moodHistory.length === 0) {
        entriesContainer.innerHTML = '<p class="text-muted small">No entries yet. Start tracking your mood!</p>';
        return;
    }
    
    entriesContainer.innerHTML = moodHistory.map(entry => `
        <div class="mood-entry d-flex justify-content-between align-items-center mb-2 p-2 bg-light rounded">
            <div>
                <span class="me-2">${entry.emoji}</span>
                <small class="text-muted">${entry.date}</small>
            </div>
            <small class="text-muted">${entry.notes || 'No notes'}</small>
        </div>
    `).join('');
}

// ============ STRESS QUIZ ============
function selectQuizAnswer(event) {
    const button = event.target;
    const questionElement = button.closest('.quiz-question');
    const questionIndex = parseInt(questionElement.dataset.question);
    const value = parseInt(button.dataset.value);
    
    // Store answer
    quizAnswers[questionIndex] = value;
    
    // Update button styles
    questionElement.querySelectorAll('.quiz-option').forEach(btn => {
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-outline-primary');
    });
    button.classList.remove('btn-outline-primary');
    button.classList.add('btn-primary');
    
    // Move to next question or show results
    setTimeout(() => {
        if (questionIndex < 2) {
            // Move to next question
            questionElement.style.transform = 'translateX(-30px)';
            questionElement.style.opacity = '0';
            questionElement.classList.remove('active');
            
            setTimeout(() => {
                const nextQuestion = document.querySelector(`[data-question="${questionIndex + 1}"]`);
                nextQuestion.classList.add('active');
                nextQuestion.style.transform = 'translateX(0)';
                nextQuestion.style.opacity = '1';
            }, 200);
        } else {
            // Show results
            questionElement.style.transform = 'translateX(-30px)';
            questionElement.style.opacity = '0';
            showQuizResults();
        }
    }, 500);
}

function showQuizResults() {
    const totalScore = quizAnswers.reduce((sum, score) => sum + score, 0);
    const maxScore = 12; // 3 questions × 4 max points
    const percentage = (totalScore / maxScore) * 100;
    
    let stressLevel, stressColor, advice;
    
    if (percentage <= 25) {
        stressLevel = 'Low Stress';
        stressColor = 'bg-success';
        advice = 'Great! You seem to be managing stress well. Keep up your healthy coping strategies.';
    } else if (percentage <= 50) {
        stressLevel = 'Mild Stress';
        stressColor = 'bg-info';
        advice = 'You\'re experiencing some stress. Consider trying our breathing exercises and self-care tools.';
    } else if (percentage <= 75) {
        stressLevel = 'Moderate Stress';
        stressColor = 'bg-warning';
        advice = 'Your stress levels are concerning. We recommend speaking with a counselor or trying our stress management tools.';
    } else {
        stressLevel = 'High Stress';
        stressColor = 'bg-danger';
        advice = 'You\'re experiencing high stress levels. Please consider reaching out to a mental health professional for support.';
    }
    
    // Hide all questions
    document.querySelectorAll('.quiz-question').forEach(q => q.classList.remove('active'));
    
    // Show results
    const resultsContainer = document.getElementById('quizResults');
    if (resultsContainer) {
        document.getElementById('stressLevel').textContent = stressLevel;
        document.getElementById('stressBar').className = `progress-bar ${stressColor}`;
        document.getElementById('stressBar').style.width = `${percentage}%`;
        document.getElementById('stressAdvice').textContent = advice;
        resultsContainer.style.display = 'block';
        resultsContainer.classList.add('fade-in');
        
        // Animate progress bar
        const progressBar = document.getElementById('stressBar');
        progressBar.style.width = '0%';
        setTimeout(() => {
            progressBar.style.width = `${percentage}%`;
        }, 300);
    }
}

function retakeQuiz() {
    quizAnswers = [];
    currentQuestion = 0;
    
    // Hide results
    document.getElementById('quizResults').style.display = 'none';
    
    // Reset all questions
    document.querySelectorAll('.quiz-question').forEach((q, index) => {
        q.classList.remove('active');
        q.style.transform = '';
        q.style.opacity = '';
        if (index === 0) q.classList.add('active');
        
        // Reset button styles
        q.querySelectorAll('.quiz-option').forEach(btn => {
            btn.classList.remove('btn-primary');
            btn.classList.add('btn-outline-primary');
        });
    });
}

// ============ POSITIVE AFFIRMATIONS ============
function showNewAffirmation() {
    const affirmationText = document.getElementById('affirmationText');
    if (!affirmationText) return;
    
    const randomIndex = Math.floor(Math.random() * affirmations.length);
    const newAffirmation = affirmations[randomIndex];
    
    // Add fade effect
    affirmationText.style.transform = 'scale(0.9)';
    affirmationText.style.opacity = '0';
    
    setTimeout(() => {
        affirmationText.textContent = newAffirmation;
        affirmationText.style.opacity = '1';
        affirmationText.style.transform = 'scale(1)';
    }, 300);
    
    // Add button animation
    const button = document.getElementById('newAffirmation');
    button.classList.add('pulse-animation');
    setTimeout(() => {
        button.classList.remove('pulse-animation');
    }, 1000);
}

// ============ CONTACT FORM ============
function handleContactForm(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const data = {
        firstName: formData.get('firstName') || document.getElementById('firstName').value,
        lastName: formData.get('lastName') || document.getElementById('lastName').value,
        email: formData.get('email') || document.getElementById('email').value,
        subject: formData.get('subject') || document.getElementById('subject').value,
        urgency: formData.get('urgency') || document.querySelector('input[name="urgency"]:checked').value,
        message: formData.get('message') || document.getElementById('message').value
    };
    
    // Simulate form submission
    const submitBtn = event.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Sending...';
    submitBtn.disabled = true;
    
    setTimeout(() => {
        // Show success message
        document.getElementById('successMessage').style.display = 'block';
        document.getElementById('successMessage').classList.add('fade-in');
        
        // Reset form
        event.target.reset();
        
        // Reset button
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
        
        // Scroll to success message
        document.getElementById('successMessage').scrollIntoView({ 
            behavior: 'smooth',
            block: 'center'
        });
        
        console.log('Form submitted:', data);
    }, 2000);
}

// ============ MEDITATION PLAYER ============
function playMeditation() {
    const button = document.getElementById('playMeditation');
    if (!button) return;
    
    // In a real implementation, this would start a meditation audio/video
    button.innerHTML = '<i class="fas fa-pause me-2"></i>Meditation Playing...';
    button.disabled = true;
    button.classList.add('pulse-animation');
    
    // Simulate meditation session
    setTimeout(() => {
        button.innerHTML = '<i class="fas fa-play me-2"></i>Start Meditation';
        button.disabled = false;
        button.classList.remove('pulse-animation');
        showToast('Meditation session completed!', 'success');
    }, 5000);
}

// ============ UTILITY FUNCTIONS ============
function showToast(message, type = 'info') {
    // Create toast element
    const toast = document.createElement('div');
    toast.className = `alert alert-${type} position-fixed fade-in`;
    toast.style.cssText = `
        top: 100px;
        right: 20px;
        z-index: 1050;
        min-width: 300px;
        opacity: 0;
        transform: translateX(100%);
        transition: all 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        border-radius: 1rem;
        box-shadow: var(--shadow-xl);
        backdrop-filter: blur(10px);
    `;
    toast.innerHTML = `
        <div class="d-flex align-items-center">
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'} me-2"></i>
            ${message}
        </div>
    `;
    
    document.body.appendChild(toast);
    
    // Animate in
    setTimeout(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateX(0)';
    }, 100);
    
    // Animate out and remove
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }, 4000);
}

function formatDate(date) {
    const options = { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    return new Date(date).toLocaleDateString('en-US', options);
}

// ============ ACCESSIBILITY ENHANCEMENTS ============
function enhanceAccessibility() {
    // Add ARIA labels for screen readers
    document.querySelectorAll('.mood-btn').forEach((btn, index) => {
        btn.setAttribute('aria-label', `Select mood: ${btn.title}`);
        btn.setAttribute('role', 'button');
        btn.setAttribute('tabindex', '0');
    });
    
    // Add keyboard navigation for custom elements
    document.querySelectorAll('.quiz-option').forEach(btn => {
        btn.setAttribute('tabindex', '0');
        btn.setAttribute('role', 'button');
        btn.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.click();
                // Add keyboard activation animation
                this.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    this.style.transform = '';
                }, 150);
            }
        });
    });
    
    // Add focus indicators
    const focusableElements = document.querySelectorAll('button, input, select, textarea, a[href]');
    focusableElements.forEach(element => {
        element.addEventListener('focus', function() {
            this.style.outline = '3px solid var(--primary-color)';
            this.style.outlineOffset = '2px';
        });
        
        element.addEventListener('blur', function() {
            this.style.outline = '';
            this.style.outlineOffset = '';
        });
    });
}

// ============ PERFORMANCE OPTIMIZATION ============
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ============ ERROR HANDLING ============
window.addEventListener('error', function(e) {
    console.error('JavaScript error:', e.error);
    // In production, you might want to send this to an error tracking service
});

// ============ BROWSER COMPATIBILITY ============
function checkBrowserCompatibility() {
    const isCompatible = 'fetch' in window && 'localStorage' in window && 'querySelector' in document;
    
    if (!isCompatible) {
        const fallbackMessage = document.createElement('div');
        fallbackMessage.className = 'alert alert-warning';
        fallbackMessage.innerHTML = `
            <h5>Browser Compatibility Notice</h5>
            <p>Some features may not work properly in your current browser. For the best experience, please update to a modern browser.</p>
        `;
        document.body.insertBefore(fallbackMessage, document.body.firstChild);
    }
    
    return isCompatible;
}

// ============ ENHANCED SCROLL EFFECTS ============
function initializeParallaxEffects() {
    const parallaxElements = document.querySelectorAll('.hero-section::before, .hero-section::after');
    
    window.addEventListener('scroll', debounce(() => {
        const scrolled = window.pageYOffset;
        const rate = scrolled * -0.5;
        
        parallaxElements.forEach(element => {
            element.style.transform = `translateY(${rate}px)`;
        });
    }, 10));
}

// ============ ENHANCED LOADING STATES ============
function showLoadingState(element) {
    const originalContent = element.innerHTML;
    element.innerHTML = '<span class="loading-spinner"></span> Loading...';
    element.disabled = true;
    
    return () => {
        element.innerHTML = originalContent;
        element.disabled = false;
    };
}

// ============ ENHANCED INTERSECTION OBSERVER ============
function initializeAdvancedAnimations() {
    const animationObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const element = entry.target;
                
                // Add different animations based on element type
                if (element.classList.contains('stat-item')) {
                    animateCounter(element.querySelector('h4'));
                } else if (element.classList.contains('progress-bar')) {
                    animateProgressBar(element);
                } else if (element.classList.contains('icon-wrapper')) {
                    element.style.animation = 'bounce 0.8s ease-out';
                }
                
                animationObserver.unobserve(element);
            }
        });
    }, { threshold: 0.5 });
    
    // Observe elements for advanced animations
    document.querySelectorAll('.stat-item, .progress-bar, .icon-wrapper').forEach(element => {
        animationObserver.observe(element);
    });
}

function animateCounter(element) {
    const target = parseInt(element.textContent);
    let current = 0;
    const increment = target / 50;
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            current = target;
            clearInterval(timer);
        }
        element.textContent = Math.floor(current) + (element.textContent.includes('%') ? '%' : '');
    }, 30);
}

function animateProgressBar(element) {
    const width = element.style.width;
    element.style.width = '0%';
    setTimeout(() => {
        element.style.width = width;
    }, 200);
}

// Initialize browser compatibility check
checkBrowserCompatibility();

// Initialize accessibility enhancements
document.addEventListener('DOMContentLoaded', enhanceAccessibility);
document.addEventListener('DOMContentLoaded', initializeAdvancedAnimations);

// ============ KEYBOARD SHORTCUTS ============
document.addEventListener('keydown', function(e) {
    // Alt + H = Home
    if (e.altKey && e.key === 'h') {
        e.preventDefault();
        window.location.href = 'index.html';
    }
    
    // Alt + T = Tools
    if (e.altKey && e.key === 't') {
        e.preventDefault();
        window.location.href = 'tools.html';
    }
    
    // Alt + C = Contact
    if (e.altKey && e.key === 'c') {
        e.preventDefault();
        window.location.href = 'contact.html';
    }
    
    // Escape = Stop breathing exercise
    if (e.key === 'Escape' && isBreathing) {
        stopBreathingExercise();
    }
});

// ============ ANALYTICS AND TRACKING ============
function trackUserInteraction(action, category = 'User Interaction') {
    // In a real implementation, this would send data to your analytics service
    console.log(`Analytics: ${category} - ${action}`);
}

// Track button clicks
document.addEventListener('click', function(e) {
    if (e.target.matches('.btn')) {
        const buttonText = e.target.textContent.trim();
        trackUserInteraction(`Button clicked: ${buttonText}`, 'UI Interaction');
    }
});

// ============ SERVICE WORKER REGISTRATION (for PWA capabilities) ============
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        // In a real implementation, you would register a service worker here
        console.log('Service Worker support detected');
    });
}

// ============ THEME DETECTION ============
function detectUserPreferences() {
    // Detect dark mode preference
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        document.body.classList.add('dark-mode-preferred');
    }
    
    // Detect reduced motion preference
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        document.body.classList.add('reduced-motion');
    }
    
    // Detect high contrast preference
    if (window.matchMedia && window.matchMedia('(prefers-contrast: high)').matches) {
        document.body.classList.add('high-contrast');
    }
}

// Initialize theme detection
document.addEventListener('DOMContentLoaded', detectUserPreferences);

// ============ ENHANCED ERROR HANDLING ============
window.addEventListener('unhandledrejection', function(event) {
    console.error('Unhandled promise rejection:', event.reason);
    showToast('Something went wrong. Please try again.', 'warning');
});

console.log('MindEase JavaScript initialized successfully ✨');
console.log('Enhanced animations and interactions loaded 🎨');